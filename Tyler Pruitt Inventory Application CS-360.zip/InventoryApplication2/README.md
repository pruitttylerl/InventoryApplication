# InventoryApplication
SNHU Inventory Application CS-360

Opens to a login screen for username and passord. The user can navigate to a notification settings screen, register login information, or submitting existing login attempts. Upon successful login attempt, 10 items will be viewable and the rest are accessible by swiping up or down. Tapping on an item pulls up an individual view of the item details. From this view, upon clicking an edit or delete button, the user can modify the item or remove it respectively.